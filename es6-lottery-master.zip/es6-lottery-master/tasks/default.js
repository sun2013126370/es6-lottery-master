import gulp from 'gulp';

//默认gulp任务，执行build
gulp.task('default',['build']);
